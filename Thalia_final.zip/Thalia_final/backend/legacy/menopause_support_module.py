import os
import json
import yaml
import openai
from dotenv import load_dotenv

load_dotenv()
openai.api_key ="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"

# Global state variables
symptom_profile = {}
conversation_history = []
assumed_zero_symptoms = []
declined_symptoms = []

class SystemMessageManager:
    def __init__(self, base_path="backend/system_message/"):
        self.base_path = base_path
        self.messages = {}
        self._load_all_messages()
    
    def _load_all_messages(self):
        try:
            self.messages = {
                "collector": self._load_file("collector_system_message.txt"),
                "calculator": self._load_file("calculator_system_message.txt")
            }
            print("✓ System messages loaded successfully")
        except FileNotFoundError as e:
            raise FileNotFoundError(f"Required system message files not found in {self.base_path}. Please ensure both collector_system_message.txt and calculator_system_message.txt exist.") from e
        except Exception as e:
            raise Exception(f"Error loading system messages: {e}") from e
    
    def _load_file(self, filename):
        filepath = os.path.join(self.base_path, filename)
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"System message file not found: {filepath}")
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                raise ValueError(f"System message file is empty: {filepath}")
            return content
    
    def get_message(self, message_type):
        if message_type not in self.messages:
            raise ValueError(f"Unknown message type: {message_type}. Available types: {list(self.messages.keys())}")
        return self.messages[message_type]

# Initialize system message manager
system_manager = SystemMessageManager()

def load_collector_template():
    try:
        with open('backend/prompts/symptom_assessment/mrs_dynamic_collector.yaml', 'r', encoding='utf-8') as file:
            template_data = yaml.safe_load(file)
            return template_data['template']
    except FileNotFoundError:
        print("Error: backend/prompts/symptom_assessment/mrs_dynamic_collector.yaml file not found!")
        return None
    except Exception as e:
        print(f"Error loading prompt template: {e}")
        return None

def load_scoring_template():
    """Load the scoring calculator template for future use"""
    try:
        with open('backend/prompts/symptom_assessment/mrs_scoring_calculator.yaml', 'r', encoding='utf-8') as file:
            template_data = yaml.safe_load(file)
            return template_data['template']
    except FileNotFoundError:
        print("Warning: mrs_scoring_calculator.yaml not found - using fallback scoring")
        return None
    except Exception as e:
        print(f"Error loading scoring template: {e}")
        return None

def call_model_with_prompt(prompt, message_type="collector"):
    """
    Call the model with the appropriate system message
    message_type: "collector" or "calculator"
    """
    try:
        system_content = system_manager.get_message(message_type)
        
        response = openai.ChatCompletion.create(
            model="gpt-4.1-mini",
            messages=[
                {"role": "system", "content": system_content},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1200
        )

        return response.choices[0].message.content
    except Exception as e:
        print(f"Error calling model: {e}")
        return None

def call_scoring_model(symptom_profile_data, assumed_zero_data, declined_data):
    """
    Call the scoring calculator with dedicated system message and template
    """
    scoring_template = load_scoring_template()
    if not scoring_template:
        # Fallback to simple calculation
        return calculate_mrs_score_fallback()
    
    try:
        formatted_prompt = safe_format_template(
            scoring_template,
            current_symptom_profile=json.dumps(symptom_profile_data, indent=2),
            assumed_zero_symptoms=json.dumps(assumed_zero_data),
            declined_symptoms=json.dumps(declined_data)
        )
        
        model_output = call_model_with_prompt(formatted_prompt, message_type="calculator")
        if model_output:
            try:
                return json.loads(model_output.strip())
            except json.JSONDecodeError:
                print("Error parsing scoring model output, using fallback calculation")
                return calculate_mrs_score_fallback()
        else:
            return calculate_mrs_score_fallback()
            
    except Exception as e:
        print(f"Error in scoring model: {e}")
        return calculate_mrs_score_fallback()

def safe_format_template(template, **kwargs):
    import re
    for key, value in kwargs.items():
        template = template.replace(f'{{{key}}}', str(value))
    placeholder_defaults = {
        'symptom_name': '[symptom]',
        'user_phrase': '[phrase]', 
        'previous_info': '[previous]',
        'new_info': '[new]',
        'assumed_zero_symptoms': '[]'
    }
    for placeholder, default in placeholder_defaults.items():
        template = template.replace(f'{{{placeholder}}}', default)
    template = re.sub(r'\{\{[^}]+\}\}', '', template)
    return template

def get_missing_symptoms_info():
    all_symptoms = {
        "physical": ["hot_flashes", "heart_discomfort", "sleep_problems", "joint_muscle_discomfort"],
        "emotional": ["depressive_mood", "irritability", "anxiety", "mental_exhaustion"],
        "functional": ["sexual_problems", "bladder_problems", "vaginal_dryness"]
    }
    missing_by_module = {"physical": [], "emotional": [], "functional": []}
    for module, symptoms in all_symptoms.items():
        for symptom in symptoms:
            if (symptom not in symptom_profile and 
                symptom not in assumed_zero_symptoms and 
                symptom not in declined_symptoms):
                missing_by_module[module].append(symptom)
    if missing_by_module["physical"]:
        current_module = "physical"
    elif missing_by_module["emotional"]:
        current_module = "emotional"
    elif missing_by_module["functional"]:
        current_module = "functional"
    else:
        current_module = "completed"
    flat_missing = []
    for symptoms in missing_by_module.values():
        flat_missing.extend(symptoms)
    return {
        "missing_symptoms": flat_missing,
        "current_module": current_module,
        "missing_by_module": missing_by_module
    }

def process_symptom_updates(symptom_updates):
    global symptom_profile, assumed_zero_symptoms, declined_symptoms
    if "scored_symptoms" in symptom_updates:
        for symptom_data in symptom_updates["scored_symptoms"]:
            symptom_name = symptom_data["symptom"]
            mrs_score = symptom_data["mrs_score"]
            symptom_profile[symptom_name] = {
                "mrs_score": mrs_score,
                "severity": get_severity_from_score(mrs_score)
            }
            if symptom_name in assumed_zero_symptoms:
                assumed_zero_symptoms.remove(symptom_name)
            if symptom_name in declined_symptoms:
                declined_symptoms.remove(symptom_name)
            print(f"✓ Updated: {symptom_name} (score: {mrs_score})")
    if "assumed_zero" in symptom_updates:
        for symptom in symptom_updates["assumed_zero"]:
            if symptom not in assumed_zero_symptoms:
                assumed_zero_symptoms.append(symptom)
                print(f"✓ Assumed zero: {symptom}")
    if "declined_symptoms" in symptom_updates:
        for symptom in symptom_updates["declined_symptoms"]:
            if symptom not in declined_symptoms:
                declined_symptoms.append(symptom)
                if symptom in assumed_zero_symptoms:
                    assumed_zero_symptoms.remove(symptom)
                print(f"✓ Declined: {symptom}")

def get_severity_from_score(mrs_score):
    severity_map = {0: "none", 1: "mild", 2: "moderate", 3: "severe", 4: "very severe"}
    return severity_map.get(mrs_score, "unknown")

def display_current_profile():
    print("\n=== Current Status ===")
    if symptom_profile:
        print("Recorded symptoms:")
        for symptom, data in symptom_profile.items():
            print(f"  {symptom}: {data['mrs_score']} ({data['severity']})")
    if assumed_zero_symptoms:
        print(f"Assumed zero: {', '.join(assumed_zero_symptoms)}")
    if declined_symptoms:
        print(f"Declined: {', '.join(declined_symptoms)}")
    info = get_missing_symptoms_info()
    print(f"Current module: {info['current_module']}")
    for module, symptoms in info['missing_by_module'].items():
        if symptoms:
            print(f"Missing {module}: {', '.join(symptoms)}")
    print("=" * 25)

def calculate_mrs_score_fallback():
    """Fallback MRS calculation if scoring model is not available"""
    total_score = 0
    symptom_count = 0
    for symptom, data in symptom_profile.items():
        if 'mrs_score' in data:
            total_score += data['mrs_score']
            symptom_count += 1
    total_symptoms = symptom_count + len(assumed_zero_symptoms) + len(declined_symptoms)
    print(f"\n=== MRS Score Calculation ===")
    print(f"Scored symptoms: {symptom_count}")
    print(f"Assumed zero symptoms: {len(assumed_zero_symptoms)}")
    print(f"Declined symptoms: {len(declined_symptoms)}")
    print(f"Total MRS Score: {total_score}")
    if declined_symptoms:
        print(f"⚠️ Note: {len(declined_symptoms)} declined symptom(s) may affect accuracy")
    if total_score <= 11:
        interpretation = "Asymptomatic (mild/no symptoms)"
    elif total_score <= 35:
        interpretation = "Mild to moderate symptoms"
    else:
        interpretation = "Severe to very severe symptoms"
    print(f"Interpretation: {interpretation}")
    if total_score >= 14:
        print("Above treatment consideration threshold (≥14)")
    else:
        print("Below treatment consideration threshold (<14)")
    print("=" * 30)
    return {
        "total_score": total_score,
        "interpretation": interpretation,
        "conversational_response": f"Your MRS score is {total_score}. {interpretation}"
    }

def calculate_mrs_score():
    """Enhanced MRS calculation using scoring model if available"""
    scoring_result = call_scoring_model(symptom_profile, assumed_zero_symptoms, declined_symptoms)
    
    if isinstance(scoring_result, dict) and "mrs_calculation" in scoring_result:
        # Use model-generated score and response
        calculation = scoring_result["mrs_calculation"]
        print(f"\n=== MRS Score Calculation ===")
        print(f"Total MRS Score: {calculation.get('total_score', 'N/A')}")
        print(f"Physical domain: {calculation.get('domain_scores', {}).get('physical', 'N/A')}")
        print(f"Emotional domain: {calculation.get('domain_scores', {}).get('emotional', 'N/A')}")
        print(f"Functional domain: {calculation.get('domain_scores', {}).get('functional', 'N/A')}")
        print("=" * 30)
        return calculation.get('total_score', 0), scoring_result.get('conversational_response', '')
    else:
        # Use fallback calculation
        fallback_result = scoring_result if isinstance(scoring_result, dict) else calculate_mrs_score_fallback()
        return fallback_result.get('total_score', 0), fallback_result.get('conversational_response', '')

def clear_assessment_state():
    """Clear all assessment state when user exits"""
    global symptom_profile, conversation_history, assumed_zero_symptoms, declined_symptoms
    symptom_profile = {}
    conversation_history = []
    assumed_zero_symptoms = []
    declined_symptoms = []
    print("🗑️ Assessment state cleared")

def process_next_action(next_action):
    """
    Process the next_action from collector response
    Returns action info for the main flow to handle
    """
    action_type = next_action.get("type", "continue_collection")
    
    if action_type == "exit_assessment":
        print("🚪 User requested to exit assessment")
        return {
            "should_exit": True,
            "exit_reason": "user_requested",
            "clear_state": True
        }
    
    elif action_type == "exit_confirmation_needed":
        detected_intent = next_action.get("detected_intent", "unknown")
        original_question = next_action.get("original_question", "")
        print(f"🤔 Detected intent: {detected_intent}")
        print(f"📝 Original question: {original_question}")
        return {
            "should_exit": False,
            "needs_confirmation": True,
            "pending_intent": detected_intent,
            "pending_question": original_question
        }
    
    elif action_type == "scoring_ready":
        print("🎯 Ready for scoring")
        return {
            "should_exit": False,
            "ready_for_scoring": True
        }
    
    else:
        # continue_collection, clarification, bundled_question, etc.
        return {
            "should_exit": False,
            "continue_assessment": True
        }

def show_full_model_output():
    current_state = getattr(show_full_model_output, 'show_debug_output', False)
    show_full_model_output.show_debug_output = not current_state
    print(f"Debug output {'enabled' if show_full_model_output.show_debug_output else 'disabled'}")

def menopause_support_enhanced(user_input, history=None):
    """
    Enhanced version that returns structured response with action information
    For use in pipeline/main flow
    """
    global symptom_profile, conversation_history, assumed_zero_symptoms, declined_symptoms
    
    prompt_template = load_collector_template()
    if not prompt_template:
        return {
            "status": "error",
            "message": "Sorry, I'm having trouble loading my configuration. Please try again.",
            "action_info": {"should_exit": False}
        }

    info = get_missing_symptoms_info()
    
    # If assessment is completed, calculate score
    if info["current_module"] == "completed":
        total_score, response = calculate_mrs_score()
        return {
            "status": "completed",
            "message": response,
            "mrs_score": total_score,
            "action_info": {"should_exit": False, "assessment_completed": True}
        }

    # Format and send prompt to collector
    formatted_prompt = safe_format_template(
        prompt_template,
        user_input=user_input,
        current_symptom_profile=json.dumps(symptom_profile, indent=2),
        conversation_history="\n".join(conversation_history[-6:]) if conversation_history else "",
        missing_symptom_list=json.dumps(info["missing_symptoms"])
    )

    # Use collector system message for symptom collection
    model_output = call_model_with_prompt(formatted_prompt, message_type="collector")
    if not model_output:
        return {
            "status": "error",
            "message": "Sorry, I'm having trouble processing your input right now. Could you try again?",
            "action_info": {"should_exit": False}
        }

    # Debug output if enabled
    if getattr(show_full_model_output, 'show_debug_output', False):
        print(f"\n{'='*20} FULL MODEL OUTPUT {'='*20}")
        print(model_output)
        print(f"{'='*60}\n")

    try:
        response_data = json.loads(model_output.strip())
        
        # Process symptom updates
        if "symptom_updates" in response_data:
            process_symptom_updates(response_data["symptom_updates"])
        
        # Get conversational response
        conversational_response = response_data.get("conversational_response", "")
        if not conversational_response:
            conversational_response = "Could you tell me more about any symptoms you're experiencing?"
        
        # 🆕 Process next_action - This is the key enhancement!
        next_action = response_data.get("next_action", {})
        action_info = process_next_action(next_action)
        
        # Handle different action types
        if action_info.get("should_exit"):
            if action_info.get("clear_state"):
                clear_assessment_state()
            return {
                "status": "user_exit",
                "message": conversational_response,
                "action_info": action_info
            }
        
        elif action_info.get("needs_confirmation"):
            return {
                "status": "needs_exit_confirmation",
                "message": conversational_response,
                "action_info": action_info
            }
        
        elif action_info.get("ready_for_scoring"):
            # Force scoring even if not all symptoms collected
            total_score, scoring_response = calculate_mrs_score()
            return {
                "status": "scoring_completed",
                "message": scoring_response or conversational_response,
                "mrs_score": total_score,
                "action_info": action_info
            }
        
        # Continue normal collection
        conversation_history.append(user_input)
        conversation_history.append(conversational_response)
        
        display_current_profile()
        
        # Check if completed after updates
        if get_missing_symptoms_info()["current_module"] == "completed":
            conversational_response += "\n\nBy the way, I now have enough information to calculate your MRS score. Just say 'score please' if you'd like to know."
        
        return {
            "status": "continuing",
            "message": conversational_response,
            "action_info": action_info
        }
        
    except json.JSONDecodeError:
        conversational_response = "Could you tell me more about any symptoms you're experiencing?"
        return {
            "status": "continuing",
            "message": conversational_response,
            "action_info": {"should_exit": False, "continue_assessment": True}
        }

def menopause_support(user_input, history=None):
    """
    Original interface for Gradio compatibility - returns string only
    """
    # Get enhanced response
    enhanced_response = menopause_support_enhanced(user_input, history)
    
    # Extract just the message for Gradio
    message = enhanced_response.get("message", "I'm having trouble processing your input.")
    
    # Handle special cases for console output
    status = enhanced_response.get("status", "continuing")
    if status == "needs_exit_confirmation":
        action_info = enhanced_response.get("action_info", {})
        print(f"🤖 [Detected: {action_info.get('pending_intent', 'unknown')} intent]")
        print(f"📝 [Original question: {action_info.get('pending_question', 'N/A')}]")
    elif status == "user_exit":
        print("🚪 Assessment ended by user request")
    elif status == "completed":
        mrs_score = enhanced_response.get("mrs_score", "N/A")
        print(f"🎉 Assessment completed! MRS Score: {mrs_score}")
    elif status == "scoring_completed":
        mrs_score = enhanced_response.get("mrs_score", "N/A")
        print(f"📊 Scoring completed! MRS Score: {mrs_score}")
    
    return message

def handle_exit_confirmation(user_confirms_exit, pending_question="", pending_intent=""):
    """
    Handle user's response to exit confirmation
    """
    if user_confirms_exit:
        clear_assessment_state()
        return {
            "status": "confirmed_exit",
            "message": "Assessment ended. I'll now help with your original question.",
            "original_question": pending_question,
            "detected_intent": pending_intent
        }
    else:
        return {
            "status": "continue_assessment",
            "message": "Great! Let's continue with your symptom assessment. Where were we?"
        }

if __name__ == "__main__":
    print("=== Enhanced Menopause Support System ===")
    print("Commands: 'quit', 'profile', 'score', 'debug'")
    print("Test phrases: 'exit assessment', 'What are good foods for menopause?'")
    print("Note: Using enhanced version for testing\n")

    # State for testing exit confirmation
    waiting_for_confirmation = False
    pending_data = {}

    while True:
        user_input = input("You: ").strip()
        
        if user_input.lower() in ['quit', 'exit']:
            break
        elif user_input.lower() == 'profile':
            display_current_profile()
        elif user_input.lower() in ['score', 'calculate score', 'yes plz', 'show my score', 'mrs score']:
            calculate_mrs_score()
        elif user_input.lower() == 'debug':
            show_full_model_output()
        elif not user_input:
            continue
        else:
            # Handle exit confirmation flow
            if waiting_for_confirmation:
                if user_input.lower() in ['yes', 'y', 'confirm', 'exit']:
                    result = handle_exit_confirmation(True, pending_data.get('question', ''), pending_data.get('intent', ''))
                    print(f"\nAssistant: {result['message']}")
                    if result.get('original_question'):
                        print(f"📝 Your original question was: {result['original_question']}")
                        print(f"🎯 Detected intent: {result['detected_intent']}")
                        print("➡️ [This would now be passed to the appropriate flow]")
                elif user_input.lower() in ['no', 'n', 'continue', 'stay']:
                    result = handle_exit_confirmation(False)
                    print(f"\nAssistant: {result['message']}")
                else:
                    print("\nAssistant: Please confirm: Do you want to exit the assessment? (yes/no)")
                    continue
                
                waiting_for_confirmation = False
                pending_data = {}
            else:
                # Normal assessment flow - use enhanced version for testing
                response = menopause_support_enhanced(user_input)
                print(f"\nAssistant: {response['message']}")
                
                # Handle different statuses
                if response['status'] == 'needs_exit_confirmation':
                    action_info = response['action_info']
                    waiting_for_confirmation = True
                    pending_data = {
                        'question': action_info.get('pending_question', ''),
                        'intent': action_info.get('pending_intent', '')
                    }
                    print(f"🤖 [Detected: {pending_data['intent']} intent]")
                elif response['status'] == 'user_exit':
                    print("🚪 Assessment ended by user request")
                elif response['status'] == 'completed':
                    print(f"🎉 Assessment completed! MRS Score: {response.get('mrs_score', 'N/A')}")
                elif response['status'] == 'scoring_completed':
                    print(f"📊 Scoring completed! MRS Score: {response.get('mrs_score', 'N/A')}")
            
            print("-" * 50)