import os
import fitz  # PyMuPDF
from .mysql_connector import get_connection

def extract_text_from_pdf(file_path):
    doc = fitz.open(file_path)
    return "\n".join(page.get_text() for page in doc)

def insert_pdf(file_path):
    text = extract_text_from_pdf(file_path)
    file_name = os.path.basename(file_path)

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM pdf_documents WHERE file_name = %s", (file_name,))
    (count,) = cursor.fetchone()

    if count>0:
        print(f"⚠️ Skipping {file_name} — already in database.")
    else:
        cursor.execute(
            "INSERT INTO pdf_documents (file_name, content) VALUES (%s, %s)",
            (file_name, text)
        )
        conn.commit()
        print(f"✅ Inserted {file_name} into database.")

    cursor.close()
    conn.close()

if __name__ == "__main__":
    pdf_folder = os.path.join(os.path.dirname(__file__), "..", "pdfs")
    for file in os.listdir(pdf_folder):
        if file.endswith(".pdf"):
            insert_pdf(os.path.join(pdf_folder, file))
