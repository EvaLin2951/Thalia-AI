# db/fetch_pdfs.py
import sys
import os

# 添加父目录到路径，以便导入其他模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    # 尝试相对导入（当作为模块被导入时）
    from .mysql_connector import get_connection
except ImportError:
    # 如果相对导入失败，使用绝对导入（当直接运行时）
    from mysql_connector import get_connection

def fetch_pdf_texts():
    """
    从数据库获取PDF文档内容
    """
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        
        # 假设表名为 pdf_documents，包含 content 和 file_name 字段
        cursor.execute("SELECT content, file_name FROM pdf_documents")
        results = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return results
    except Exception as e:
        print(f"Database error: {e}")
        return []

if __name__ == "__main__":
    documents = fetch_pdf_texts()
    for doc in documents:  # 修复了之前的解构问题
        print(f"\n📄 {doc['file_name']}\n{'-'*60}\n{doc['content'][:1000]}...\n")