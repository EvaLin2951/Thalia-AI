USE rag_docs;

-- Drop the main table (CAUTION: this deletes all PDF data)
DROP TABLE IF EXISTS pdf_documents;
