from mysql_connector import get_connection

def fetch_pdf_texts():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT file_name, content FROM pdf_documents")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return [{"file_name": r[0], "content": r[1]} for r in rows]


if __name__ == "__main__":
    docs = fetch_pdf_texts()
    for doc in docs:
        print(f"\n {doc['file_name']}\n{'-'*50}\n{doc['content'][:500]}...\n")