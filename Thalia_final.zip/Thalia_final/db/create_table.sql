-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS thalia_bot;
USE thalia_bot;

-- Create the main table for storing PDFs
CREATE TABLE IF NOT EXISTS pdf_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    file_name VARCHAR(255) NOT NULL UNIQUE,
    content LONGTEXT,                   -- Extracted text for RAG
    --pdf_blob LONGBLOB,                  -- Optional: full PDF file
    --file_path VARCHAR(512),            -- Optional: original path or cloud URL
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
