"""
Configuration file - Stores application configuration and constants
"""
import os

# Get our logo
LOGO_PATH = "assets/thalia_final.png"

# Application configuration
APP_CONFIG = {
    "title": "Thalia - Menopause Support Platform",
    "theme": "soft",
    "server_name": "0.0.0.0", 
    "server_port": 7860,
    "max_width": "1200px",
    "share": False,
    "show_error": True
}

# File paths
USER_DATA_FILE = "thalia_users.json"
AVATAR_PATH = "assets/thalia_avatar.png"

# UI text and messages
WELCOME_MESSAGE = """Hello and welcome! I'm Thalia 🦋 your trusted companion for navigating menopause with confidence and clarity.

**Having specific symptoms?** I can help you assess what you're experiencing using validated tools and guide you on when it might be time to talk with your healthcare provider.

**Need reliable information?** I'll share the latest evidence-based research on everything from hormone therapy to natural approaches, lifestyle strategies, and long-term health considerations—all explained in plain language you can trust.

**Just need someone who gets it?** I'm here to listen without judgment, validate your experiences, and offer practical support for the emotional ups and downs that come with this transition.

You've got this, and I've got you. Let's begin wherever feels right. 💕"""

PLATFORM_DESCRIPTION = {
    "title": "🌸 Menopause Support & Education Platform",
    "content": """Evidence-based menopause education for women 35+, whether you're just starting to notice changes or are well into your transition. 
Every conversation is confidential, culturally sensitive, and tailored to your unique needs.<br>
<strong>Disclaimer:</strong> This platform provides educational information only and does not replace professional medical consultation."""
}

# Privacy and Terms Configuration
PRIVACY_DISCLAIMER = {
    "title": "🔒 Privacy Statement & Terms of Use",
    "content": """
    <div style='background: linear-gradient(135deg, #f3e5f5, #fce4ec); border-radius: 10px; padding: 25px; margin: 20px 0; border-left: 4px solid #8e24aa;'>
        <h4 style='color: #6a1b9a; margin-bottom: 15px;'>📋 Please Read Carefully Before Using Thalia</h4>
        
        <div style='font-size: 16px; line-height: 1.6; color: #333;'>
            <p><strong>To provide you with personalized menopause support services, we need to inform you of the following important information:</strong></p>
            
        <div style='font-size: 16px; line-height: 1.6; color: #333;'>
            <ul style='margin: 15px 0; padding-left: 25px;'>
                <li><strong>What We Do:</strong> Thalia is an intelligent chatbot that provides evidence-based menopause education, symptom explanations, and emotional support. We're dedicated to creating an empowering and inclusive space where women can access reliable information throughout their menopause journey.</li>
                <li><strong>Data Usage & Privacy Protection:</strong> To deliver personalized menopause support, Thalia processes your symptoms, experiences, and health-related information through advanced language models. We strictly protect your personal privacy and will not use your information for other purposes or share it with third parties. Your conversation records are securely stored and used exclusively to provide tailored advice and maintain continuity in your care experience.</li>
                <li><strong>Medical Disclaimer:</strong> Thalia offers research-based information and assessment tools like the MRS (Menopause Rating Scale). However, Thalia does not replace professional medical consultation. Please consult healthcare providers for medical diagnosis and treatment decisions.</li>
            </ul>
            
            <div style='background: linear-gradient(135deg, #e3f2fd, #f0f8ff); border-radius: 8px; padding: 15px; margin: 15px 0; border-left: 3px solid #2196f3;'>
                <p style='margin: 0; font-weight: 500;'>⚠️ <strong>Important Reminder:</strong> Please avoid entering extremely sensitive personal information (such as specific medical record numbers, ID numbers, etc.). We recommend that you share your feelings and symptoms in a descriptive manner.</p>
            </div>
        </div>
    </div>
    """,
    "checkbox_text": "I have carefully read and understand the above statement, and agree to have my information processed by large language models to receive personalized menopause support services",
    "button_text": "I Agree and Continue",
    "decline_text": "I Do Not Agree"
}

# Example questions
EXAMPLE_QUESTIONS = [
    "I've been having irregular periods and hot flashes",
    "My sleep is terrible and I'm gaining weight", 
    "I'm so moody lately - could this be perimenopause?",
    "What's the difference between perimenopause and menopause?",
    "Is HRT right for me?",
    "What are the best natural options for hot flashes?",
    "I feel like I'm losing myself in this transition",
    "Nobody seems to understand what I'm going through"
]

# Age range options
AGE_RANGES = ["25-34", "35-44", "45-54", "55-64", "65+"]

# Error messages
ERROR_MESSAGES = {
    "auth_unavailable": "❌ Authentication system unavailable",
    "user_manager_uninitialized": "❌ UserManager not initialized",
    "invalid_session": "❌ Invalid session, user not logged in",
    "system_unavailable": ("I apologize, but my systems are currently unavailable. "
                          "Please try again later or consult with a healthcare professional "
                          "for immediate menopause-related concerns."),
    "processing_error": ("I encountered an error processing your request. "
                        "Please try rephrasing your question or try again.")
}

# Success messages
SUCCESS_MESSAGES = {
    "registration_success": "✅ {message}\n\nPlease go to the login tab to sign in with your new account.",
    "login_success": "✅ {message}",
    "logout_success": "✅ Logout: {message}"
}